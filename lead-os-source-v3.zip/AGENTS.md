# Lead OS — product and engineering guardrails

## Product goal

Lead OS is a configurable operations system that helps a good B2B sales leader become better. Its primary advantage is people intelligence: one coherent view of employee context assembled from 1:1s, meeting notes, transcripts, promises, motivation, engagement, agreements and performance data.

The product must solve observable leadership and sales-operation problems. Do not add features merely because they are technically possible.

## Core experiences

1. Leader cockpit: attention compass, people signals, sales performance, approvals and leadership rhythm.
2. Seller cockpit: day/week/month results, goals, average order, commission estimate and next commission threshold.
3. TV board: daily and monthly revenue, complete leaderboard, latest sales and progress toward commission thresholds.

## Compass

The compass is an attention engine, not a task counter. It prioritizes categories and explains why:

- Coach: motivation, overdue 1:1s, broken leader promises, recognition and onboarding.
- Drive: daily pace, new-customer gap, average-order decline, sales mix and commission-tier progress.
- Decide: discounts, special agreements, approvals and owner dependencies.
- Operate: meetings, follow-up, reviews and leadership rhythm.

Every recommendation must be traceable to concrete signals. Keep the final decision with the leader.

## Nordic Tools default configuration

These are editable tenant settings, not global hard-coded truth:

- Commission is based only on orders sent from the warehouse.
- Returns and cancellations are deducted.
- 5% below DKK 200,000, 10% from DKK 200,000 and 15% from DKK 300,000.
- The achieved rate applies to all qualifying revenue for the period.
- New Sales and Resale use the same model until configured otherwise.
- A special commission rate on an order requires manager approval and an audit entry.
- Removing, returning or changing an order must never erase history; production should use reversal records and an audit log.

Discount approvals should capture requested price, standard price, product/category, estimated margin, seller rationale, approver and outcome. Do not automate Michael's pricing judgment until actual decision rules, purchase costs and minimum-margin boundaries have been documented.

## Data and AI principles

- Deterministic business rules calculate revenue, commission, thresholds and approval states.
- AI interprets conversations and patterns; it must not invent facts or silently change commercial data.
- AI-derived insights must retain links to their source conversation, note or metric.
- Human approval is required for sensitive conclusions, compensation changes and commercial exceptions.
- Tenant-specific terminology, teams, thresholds and workflows belong in configuration.
- Protect employee data with role-based access, consent, retention rules and a complete audit trail before using real recordings or personnel data.

## Current state

The current app is a clickable validation demo with illustrative data. Treat demo data and buttons as product hypotheses, not production integrations. Before production use, add authenticated roles, persistent data, validation, audit logs, monitoring and tested integrations to the order/ERP source.

## Development workflow

- Install: `npm ci`
- Develop: `npm run dev`
- Verify every change: `npm run build`
- Preserve `.openai/hosting.json`; it links this source tree to the existing Sites project.
- Never commit secrets or customer exports.
- Prefer small, reversible commits. Preserve the current warm, people-first visual language unless a requested change explicitly replaces it.

