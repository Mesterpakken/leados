"use client";

import { useState } from "react";

type Section = "overview" | "sales" | "team" | "meetings" | "calendar" | "compensation" | "decisions" | "seller" | "tv";

const nav: { id: Section; label: string; icon: string }[] = [
  { id: "overview", label: "Overblik", icon: "⌁" },
  { id: "sales", label: "Salg", icon: "↗" },
  { id: "team", label: "Mennesker", icon: "◎" },
  { id: "meetings", label: "Samtaler", icon: "◫" },
  { id: "calendar", label: "Ledelsesrytme", icon: "□" },
  { id: "compensation", label: "Løn & provision", icon: "≈" },
  { id: "decisions", label: "Beslutninger", icon: "◇" },
];

const compassSignals = {
  Coach: { score: 82, reasons: ["Camillas motivation er faldet", "Rasmus mangler 1:1", "Anders mangler anerkendelse"] },
  Drive: { score: 64, reasons: ["Nysalg er 2 kunder efter dagsmål", "Gennemsnitsordre i gensalg er faldet 8%"] },
  Decide: { score: 48, reasons: ["3 rabatter afventer godkendelse", "2 specialprovisioner kræver Michael"] },
  Operate: { score: 31, reasons: ["Kvartalssamtaler er 4 dage bag planen"] },
};

const commissionTiers = [{ threshold: 0, rate: .05 }, { threshold: 200000, rate: .10 }, { threshold: 300000, rate: .15 }];
const commissionFor = (revenue:number) => { const tier=[...commissionTiers].reverse().find(t=>revenue>=t.threshold)!; return { rate:tier.rate, amount:revenue*tier.rate }; };
const nextTierFor = (revenue:number) => commissionTiers.find(t=>t.threshold>revenue);

const sales = [
  { name: "Jørgen", amount: 150000, orders: 8, target: 125000, status: "Stærk uge" },
  { name: "Christian", amount: 87000, orders: 11, target: 100000, status: "På vej" },
  { name: "Sofie", amount: 112500, orders: 14, target: 110000, status: "I mål" },
  { name: "Martin", amount: 68200, orders: 9, target: 100000, status: "Kræver fokus" },
  { name: "Emil", amount: 94100, orders: 12, target: 100000, status: "På vej" },
];

const money = (n: number) => new Intl.NumberFormat("da-DK").format(n) + " kr.";

export default function Home() {
  const [section, setSection] = useState<Section>("overview");
  const [toast, setToast] = useState("");
  const [range, setRange] = useState("Denne uge");
  const [filter, setFilter] = useState("Alle");

  const currentFocus = Object.entries(compassSignals).sort((a,b)=>b[1].score-a[1].score)[0][0];

  function notify(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2200);
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-mark">L</span><div><strong>Lead OS</strong><small>Commercial operating system</small></div></div>
        <div className="workspace"><span>NT</span><div><b>Nordic Tools</b><small>Demo workspace</small></div><i>⌄</i></div>
        <nav>
          <p>ARBEJDSRUM</p>
          {nav.map(item => <button key={item.id} className={section === item.id ? "active" : ""} onClick={() => setSection(item.id)}><span>{item.icon}</span>{item.label}</button>)}
          <p>VISNING</p>
          <button onClick={() => setSection("seller")} className={section === "seller" ? "active" : ""}><span>◉</span>Mit sælgercockpit</button>
          <button onClick={() => setSection("tv")} className={section === "tv" ? "active" : ""}><span>▣</span>TV-tavle</button>
        </nav>
        <div className="sidebar-bottom"><div className="avatar">MN</div><div><b>Mathias Nitzsch</b><small>Rådgiver · administrator</small></div><button>•••</button></div>
      </aside>

      <main className="main">
        <header>
          <div><p className="eyebrow">SØNDAG · 2. AUGUST</p><h1>{titleFor(section)}</h1></div>
          <div className="header-actions">
            <select value={range} onChange={e => setRange(e.target.value)} aria-label="Periode"><option>Denne uge</option><option>Denne måned</option><option>Dette kvartal</option></select>
            <button className="icon-button" aria-label="Notifikationer">●</button>
            <button className="primary" onClick={() => notify("Ny aktivitet er klar til registrering")}>+ Registrér aktivitet</button>
          </div>
        </header>

        {section === "overview" && <Overview currentFocus={currentFocus} setSection={setSection} />}
        {section === "sales" && <Sales filter={filter} setFilter={setFilter} notify={notify} />}
        {section === "team" && <Team setSection={setSection} />}
        {section === "meetings" && <Meetings notify={notify} />}
        {section === "calendar" && <LeadershipCalendar />}
        {section === "compensation" && <Compensation notify={notify} />}
        {section === "decisions" && <Decisions notify={notify} />}
        {section === "seller" && <SellerCockpit />}
        {section === "tv" && <TvBoard onExit={() => setSection("overview")} />}
      </main>
      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}

function titleFor(section: Section) {
  return ({ overview: "God eftermiddag, Mathias", sales: "Salg og performance", team: "Menneskene", meetings: "Samtalecenter", calendar: "Ledelsesrytme", compensation: "Løn og provision", decisions: "Beslutningslog", seller: "Mit cockpit", tv: "Live salgstavle" })[section];
}

function Overview({ currentFocus, setSection }: any) {
  const angle = ({ Coach: -55, Drive: 35, Decide: 125, Operate: 215 } as any)[currentFocus] ?? -55;
  return <div className="content">
    <section className="intro-row"><div><h2>Dit kompas peger mod <em>{currentFocus.toLowerCase()}</em></h2><p>Se mennesket bag tallene. Lead OS husker samtaler, signaler, løfter og udvikling — og viser dig, hvor din ledelse gør størst forskel.</p></div><span className="health"><i /> 3 menneskelige signaler kræver opmærksomhed</span></section>
    <div className="overview-grid">
      <article className="card compass-card">
        <div className="card-head"><div><span className="kicker">LEDERKOMPAS</span><h3>Hvor skal du lægge dit fokus?</h3></div><span className="live">LIVE</span></div>
        <div className="compass-wrap">
          <div className="compass">
            <span className="north">COACH</span><span className="east">DRIVE</span><span className="south">DECIDE</span><span className="west">OPERATE</span>
            <div className="rings" />
            <div className="needle" style={{ transform: `rotate(${angle}deg)` }}><i /></div><b>LOS</b>
          </div>
          <div className="focus-bars">
            {Object.entries(compassSignals).map(([name, data]) => <div key={name}><span>{name}<b>{data.score}</b></span><i><u style={{ width: `${data.score}%` }} /></i></div>)}
            <p><b>Hvorfor {currentFocus}?</b><br/>{compassSignals[currentFocus as keyof typeof compassSignals].reasons.slice(0,2).join(" · ")}</p>
          </div>
        </div>
      </article>
      <article className="card attention-card">
        <div className="card-head"><div><span className="kicker">MENNESKELIG INTELLIGENS</span><h3>Hvem kræver din opmærksomhed?</h3></div><b>3</b></div>
        <div className="signal-stack">
          <button onClick={() => setSection("team")}><span className="signal-avatar">CH</span><div><small>MOTIVATION · LØFTE</small><strong>Camilla venter stadig på dig</strong><p>Motivation faldet fra 8,1 til 5,2 efter en udviklingsopfølgning, du lovede.</p><em>3 kilder samlet</em></div><b>›</b></button>
          <button onClick={() => setSection("team")}><span className="signal-avatar">AM</span><div><small>PERFORMANCE · ANERKENDELSE</small><strong>Anders leverer — men bliver ikke set</strong><p>126% af målet. Ingen registreret anerkendelse i 21 dage.</p><em>2 kilder samlet</em></div><b>›</b></button>
          <button onClick={() => setSection("team")}><span className="signal-avatar">LE</span><div><small>ONBOARDING</small><strong>Louise mangler sidemandsoplæring</strong><p>Uge 3. Produktsikkerhed 5/10. Ingen læringsaftale booket.</p><em>2 kilder samlet</em></div><b>›</b></button>
        </div>
      </article>
    </div>
    <div className="metric-grid">
      <Metric label="OMSÆTNING · UGE" value="511.800 kr." delta="+18,4%" note="mod sidste uge" />
      <Metric label="GENNEMSNITSORDRE" value="9.145 kr." delta="+1.260" note="over 30 dage" />
      <Metric label="AKTIVE MULIGHEDER" value="14" delta="412.000 kr." note="samlet potentiale" />
      <Metric label="1:1 STATUS" value="12 / 16" delta="4 mangler" note="denne cyklus" warning />
    </div>
    <div className="split-grid">
      <article className="card"><div className="card-head"><div><span className="kicker">TEAMETS PULS</span><h3>Hvem kræver din opmærksomhed?</h3></div><button className="text-button" onClick={() => setSection("team")}>Se alle ›</button></div><People /></article>
      <article className="card"><div className="card-head"><div><span className="kicker">KOMMENDE</span><h3>Næste syv dage</h3></div><button className="text-button">Åbn kalender ›</button></div><Timeline /></article>
    </div>
  </div>;
}

function Metric({ label, value, delta, note, warning }: any) { return <article className="metric"><span>{label}</span><strong>{value}</strong><p className={warning ? "warning" : ""}>{delta} <small>{note}</small></p></article>; }

function Sales({ notify }: any) {
  const [view,setView]=useState("Samlet");
  const metrics = view==="Nysalg" ? [
    ["NYE KUNDER · I DAG","7","2 under dagsmål",""],["NYE KUNDER · MÅNED","84","+11% mod juli",""],["GNS. FØRSTE ORDRE","7.840 kr.","−640 kr. denne uge","warn"],["KONVERTERING","18,6%","+2,1 procentpoint",""]
  ] : view==="Gensalg" ? [
    ["OMSÆTNING · I DAG","184.600 kr.","+8% mod dagsmål",""],["OMSÆTNING · MÅNED","2.948.400 kr.","62% af månedsmål",""],["GNS. ORDRE","9.420 kr.","−8% mod sidste uge","warn"],["STORORDRE-PIPELINE","412.000 kr.","6 aktive muligheder",""]
  ] : [
    ["OMSÆTNING · I DAG","247.800 kr.","+4,8% mod dagsmål",""],["OMSÆTNING · MÅNED","3.582.000 kr.","64% af månedsmål",""],["NYSALG · GNS. ORDRE","7.840 kr.","7 nye kunder i dag",""],["GENSALG · GNS. ORDRE","9.420 kr.","−8% mod sidste uge","warn"]
  ];
  return <div className="content"><div className="toolbar"><div className="tabs">{["Samlet","Nysalg","Gensalg"].map(x=><button key={x} className={view===x?"active":""} onClick={()=>setView(x)}>{x}</button>)}</div><button className="secondary" onClick={()=>notify("TV-tavlen er opdateret")}>Opdatér TV-tavle</button></div>
    <div className="metric-grid">{metrics.map(m=><Metric key={m[0]} label={m[0]} value={m[1]} delta={m[2]} note="" warning={m[3]==="warn"}/>)}</div>
    <div className="sales-split"><article className="card"><div className="card-head"><div><span className="kicker">LEDERENS LÆSNING</span><h3>{view==="Nysalg"?"Nye kunder kommer ind — men for billigt":view==="Gensalg"?"Tempoet holder, ordrestørrelsen falder":"Dagen er på mål, men kvaliteten er ujævn"}</h3></div><span className="live">LIVE</span></div><p className="insight-copy">{view==="Nysalg"?"Aktiviteten er tilstrækkelig. Fokus bør ligge på behovsafdækning og større første ordrer — ikke flere opkald.":view==="Gensalg"?"Tre sælgere står for hovedparten af faldet i gennemsnitsordre. Storordre-reviewet bør prioriteres før mere generel træning.":"Nysalg mangler to kunder, mens gensalg ligger over dagsmålet. Kompasset vægter derfor Drive som sekundær retning."}</p></article><article className="card"><span className="kicker">AFDELINGSTEMPO</span><div className="dept-row"><span><b>Nysalg</b><small>7 / 9 nye kunder</small></span><div className="progress"><i style={{width:"78%"}}/></div><em>78%</em></div><div className="dept-row"><span><b>Gensalg</b><small>184.600 / 171.000 kr.</small></span><div className="progress"><i style={{width:"100%"}}/></div><em>108%</em></div></article></div>
    <article className="card table-card"><div className="card-head"><div><span className="kicker">PERFORMANCE · {view.toUpperCase()}</span><h3>Det lederen skal reagere på</h3></div><span className="muted">Dagens tal · sælgerregistreret · ledergodkendt</span></div><table><thead><tr><th>Sælger</th><th>Afdeling</th><th>I dag</th><th>Måned</th><th>Gns. ordre</th><th>Næste provisionstrin</th></tr></thead><tbody>{sales.map((s,i)=><tr key={s.name}><td><span className="person-dot">{s.name[0]}</span><b>{s.name}</b></td><td>{i<2?"Nysalg":"Gensalg"}</td><td>{money(12400+i*5900)}</td><td>{money(s.amount+(i*28000))}</td><td>{money(Math.round((s.amount+(i*8000))/(s.orders+5)))}</td><td>{nextTierFor(s.amount+i*28000)?money(nextTierFor(s.amount+i*28000)!.threshold-(s.amount+i*28000)):"Toptrin nået"}</td></tr>)}</tbody></table></article>
  </div>;
}

const people = [
  {name:"Camilla Holm",role:"Senior salgskonsulent",initials:"CH",motivation:"5,2",performance:"94%",last:"23 dage",promises:2,signal:"Opfølgning forsinket",tone:"attention"},
  {name:"Anders Møller",role:"Salgskonsulent",initials:"AM",motivation:"8,4",performance:"126%",last:"12 dage",promises:0,signal:"Ingen anerkendelse i 21 dage",tone:"growth"},
  {name:"Jonas Berg",role:"Salgskonsulent",initials:"JB",motivation:"7,8",performance:"108%",last:"8 dage",promises:1,signal:"Teamlead-kandidat",tone:"growth"},
  {name:"Louise Eriksen",role:"Nyansat · uge 3",initials:"LE",motivation:"6,5",performance:"62%",last:"5 dage",promises:1,signal:"Onboarding-risiko",tone:"attention"},
  {name:"Mikkel Sørensen",role:"Salgskonsulent",initials:"MS",motivation:"6,8",performance:"78%",last:"3 dage",promises:0,signal:"Lav konvertering",tone:"neutral"},
  {name:"Rasmus Toft",role:"Salgskonsulent",initials:"RT",motivation:"4,8",performance:"68%",last:"31 dage",promises:1,signal:"Lav motivation",tone:"attention"},
];

function Team({ setSection }: any) {
  const [selected,setSelected]=useState<any>(null); const [filter,setFilter]=useState("Alle");
  if(selected) return <PersonProfile person={selected} onBack={()=>setSelected(null)} onMeeting={()=>setSection("meetings")}/>;
  const list=people.filter(p=>filter==="Alle"||(filter==="Opmærksomhed"&&p.tone==="attention")||(filter==="Topperformere"&&parseInt(p.performance)>100)||(filter==="Forsinket 1:1"&&parseInt(p.last)>20));
  return <div className="content people-page"><div className="people-intro"><div><span className="kicker">DIT MENNESKELIGE CRM</span><h2>Forstå hele mennesket — over tid</h2><p>Én sammenhængende hukommelse på tværs af samtaler, noter, resultater, løfter og daglige signaler.</p></div><button className="primary">+ Tilføj medarbejder</button></div><div className="toolbar"><div className="tabs">{["Alle","Opmærksomhed","Topperformere","Forsinket 1:1"].map(x=><button key={x} className={filter===x?"active":""} onClick={()=>setFilter(x)}>{x}</button>)}</div><span className="muted">{list.length} medarbejdere</span></div><div className="people-cards">{list.map(p=><button className="person-insight-card" key={p.name} onClick={()=>setSelected(p)}><div className="person-top"><span className="large-avatar">{p.initials}</span><div><h3>{p.name}</h3><p>{p.role}</p></div><span className={`signal-tag ${p.tone}`}>{p.signal}</span></div><div className="person-signals"><div><small>Motivation</small><b>{p.motivation}</b></div><div><small>Performance</small><b>{p.performance}</b></div><div><small>Seneste 1:1</small><b>{p.last}</b></div><div><small>Åbne løfter</small><b>{p.promises}</b></div></div><div className="person-action"><span>Åbn menneskebillede</span><b>›</b></div></button>)}</div></div>;
}

function PersonProfile({person,onBack,onMeeting}:any){return <div className="content profile-page"><button className="back-button" onClick={onBack}>← Alle mennesker</button><section className="profile-hero"><div className="profile-identity"><span className="profile-avatar">{person.initials}</span><div><span className="kicker">MEDARBEJDERBILLEDE · 18 KILDER</span><h2>{person.name}</h2><p>{person.role} · Danmark Salg · 3 år 2 måneder</p></div></div><div className="profile-actions"><button className="secondary">+ Note</button><button className="secondary">+ Løfte</button><button className="primary" onClick={onMeeting}>Forbered 1:1</button></div></section><section className="reading card"><div><span className="kicker">LEAD OS · LÆSNING</span><h3>Det vigtigste at forstå lige nu</h3><p>{person.name.split(" ")[0]} er en stærk performer, der responderer godt på konkret ansvar og direkte anerkendelse. Motivationen er faldet fra 8,1 til 5,2, mens performance er forblevet stabil. Du lovede at følge op på udviklingsplanen — ingen opfølgning er registreret. Det er sandsynligvis den vigtigste årsag til faldet.</p><small>Syntetiseret fra 1:1, check-ins, noter, løfter og salgsdata</small></div><aside><span className="signal-tag attention">Kræver opmærksomhed</span><dl><div><dt>Motivation</dt><dd>5,2 <small>↓ 2,9</small></dd></div><div><dt>Energi</dt><dd>6/10</dd></div><div><dt>Målopfyldelse</dt><dd>94%</dd></div></dl></aside></section><div className="profile-grid"><section className="card"><div className="card-head"><div><span className="kicker">FORLØBET</span><h3>En levende hukommelse</h3></div><button className="text-button">Alle kilder</button></div><div className="journey">{[["7. jul","Check-in","Motivation 5,2 — “Jeg mangler tydelighed på næste skridt.”","Camilla"],["30. jun","Check-in","Teamlead-samtalen føles stadig uafsluttet.","Camilla"],["16. jun","Kvartalssamtale","I drøftede teamlead-ambitioner. Du lovede opfølgning inden 1. juli.","Løfte"],["23. maj","1:1","Q2-performance 92%. Positiv energi og ønske om mere ansvar.","Samtale"],["25. apr","Anerkendelse","Stærk Q1-afslutning. Synlig positiv effekt på motivation.","Ledernote"]].map((x,i)=><article key={x[0]}><i className={i===2?"urgent":""}/><time>{x[0]}</time><div><small>{x[1]} · {x[3]}</small><p>{x[2]}</p></div></article>)}</div></section><section className="card human-guide"><span className="kicker">SÅDAN GÅR DU TIL HENDE</span><h3>Ledelsesmanualen, der bliver klogere</h3><div className="guide-block positive"><b>Det giver energi</b><p>Konkret ansvar, synlige milepæle og specifik anerkendelse.</p></div><div className="guide-block negative"><b>Det dræner</b><p>Uafsluttede samtaler, uklare løfter og udvikling uden handling.</p></div><div className="guide-block"><b>Feedback</b><p>Vær specifik og kort. Start med én observation, spørg hvad hun tænker, og aftal ét næste skridt.</p></div><small>Baseret på observeret adfærd — ikke en fast persontype</small></section></div><div className="profile-grid lower"><section className="card"><span className="kicker">ÅBNE LØFTER</span><h3>Det I har lovet hinanden</h3>{[["Leder","Følg op på udviklingsplan","9 dage forsinket"],["Leder","Book produkttræning","Forsinket"],["Camilla","Forbered 3 coaching-eksempler","Forfalder 16. aug"]].map(x=><div className="promise" key={x[1]}><span>{x[0]}</span><b>{x[1]}</b><em>{x[2]}</em></div>)}</section><section className="card"><span className="kicker">UDVIKLING</span><h3>Fra samtale til synlig fremdrift</h3>{[["Blive teamlead-kandidat","Drøft ansvar og tidslinje","68%"],["Større kunder","Book produkttræning","42%"],["Køre team-warmup","Aftal startdato","20%"]].map(x=><div className="development" key={x[0]}><span><b>{x[0]}</b><small>{x[1]}</small></span><div className="progress"><i style={{width:x[2]}}/></div><em>{x[2]}</em></div>)}</section></div></div>}

function Meetings({ notify }: any) { const [mode,setMode]=useState<"prepare"|"live"|"summary">("prepare"); if(mode==="live")return <MeetingLive onStop={()=>setMode("summary")}/>; if(mode==="summary")return <MeetingSummary onDone={()=>{setMode("prepare");notify("Indsigter er føjet til Camillas forløb")}}/>; return <div className="content"><div className="meeting-context"><span className="large-avatar">CH</span><div><span className="kicker">AI-FORBEREDELSE · 18 KILDER</span><h2>1:1 med Camilla Holm</h2><p>25 minutter · direkte, støttende og konkret</p></div><span className="signal-tag attention">Motivation falder + forsinket opfølgning</span></div><div className="meeting-layout"><article className="card agenda"><span className="kicker">FORESLÅET DAGSORDEN</span><h3>Det vigtigste at få talt om</h3>{["Anerkend stabil performance", "Tag ansvar for den manglende opfølgning", "Spørg ind til motivationen", "Vend tilbage til teamlead-målet", "Aftal ét konkret næste skridt"].map((x,i)=><div className="agenda-item" key={x}><span>0{i+1}</span><b>{x}</b><i>⠿</i></div>)}<button className="primary wide" onClick={()=>setMode("live")}>● Start og optag møde</button></article><article className="card question-card"><span className="kicker">FORESLÅEDE SPØRGSMÅL</span><h3>Åbn med nysgerrighed</h3>{["Sidst talte vi om mere ansvar. Er det stadig noget, du ønsker?","Din motivation er faldet — hvad har ændret sig?","Hvor synes du, jeg ikke har fulgt godt nok op?","Hvad ville gøre de næste to uger meningsfulde?"].map((q,i)=><div className="question" key={q}><span>0{i+1}</span><p>{q}</p></div>)}<div className="meeting-promises"><b>Løfter at gennemgå</b><p>Du: Booke produkttræning <em>Forsinket</em></p><p>Camilla: Beskrive teamlead-ansvar <em>Afventer</em></p></div></article></div></div>; }

function MeetingLive({onStop}:any){const [checked,setChecked]=useState<number[]>([]);return <div className="meeting-live"><header><div><span className="live-dot"/><span>OPTAGER · 12:48</span></div><h2>1:1 med Camilla Holm</h2><button onClick={onStop}>■ Stop møde</button></header><main><section><span className="kicker">DAGSORDEN</span><h3>Hold retningen — ikke manuskriptet</h3>{["Anerkend stabil performance","Tag ansvar for manglende opfølgning","Spørg ind til motivationen","Vend tilbage til teamlead-målet","Aftal næste skridt"].map((x,i)=><button className={checked.includes(i)?"live-item checked":"live-item"} onClick={()=>setChecked(v=>v.includes(i)?v.filter(n=>n!==i):[...v,i])} key={x}><i>{checked.includes(i)?"✓":""}</i><span>{x}</span></button>)}</section><section className="transcript"><div className="card-head"><div><span className="kicker">SAMTALEHUKOMMELSE</span><h3>Lead OS lytter efter det vigtige</h3></div><span className="transcribing">● TRANSSKRIBERER</span></div><div className="wave"><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/></div><div className="live-insights"><article><small>NYT EMNE</small><p>Camilla vil gerne prøve teamlead-ansvaret af uden at opgive sin egen portefølje.</p></article><article><small>MOTIVATIONSSIGNAL</small><p>“Jeg mistede lidt troen på, at der skete noget efter vores sidste samtale.”</p></article><article><small>MULIG AFTALE</small><p>Camilla tager mandagens warmup de næste to uger.</p></article></div><p className="privacy">Lyd slettes efter behandling · deltagerens samtykke skal registreres</p></section></main></div>}

function MeetingSummary({onDone}:any){return <div className="content summary-page"><div className="summary-head"><div><span className="kicker">SAMTALEN ER AFKODET</span><h2>Fra 28 minutters samtale til vedvarende indsigt</h2><p>Gennemgå før Lead OS opdaterer Camillas menneskebillede.</p></div><span className="summary-check">✓</span></div><div className="summary-grid"><article className="card"><span className="kicker">KORT FORTALT</span><h3>Camilla vil fremad — men har mistet tillid til opfølgningen</h3><p>Samtalen bekræfter, at teamlead-ambitionen stadig er aktiv. Faldet i motivation handler ikke om arbejdsopgaverne, men om at udviklingsaftaler ikke er blevet fulgt til dørs.</p><div className="source-note">Baseret på transskription · lederens noter · tidligere forløb</div></article><article className="card"><span className="kicker">SIGNALER OPDATERET</span>{[["Motivation","5,2 → 6,1"],["Engagement","Stiger ved ejerskab"],["Risiko","Mellem → Lav"],["Tema","Tillid til opfølgning"]].map(x=><div className="summary-row" key={x[0]}><span>{x[0]}</span><b>{x[1]}</b></div>)}</article><article className="card"><span className="kicker">AFTALER & LØFTER</span>{[["Camilla","Kører mandagens warmup i to uger","17. aug"],["Mathias","Sender ramme for teamlead-rollen","5. aug"],["Begge","15 min. opfølgning","19. aug"]].map(x=><div className="extracted" key={x[1]}><i>✓</i><div><small>{x[0]} · {x[2]}</small><p>{x[1]}</p></div></div>)}</article><article className="card"><span className="kicker">LEDERLÆRING</span><h3>Det systemet har lært om Camilla</h3><p>Hun responderer ikke kun på ansvar. Hun har brug for, at aftaler hurtigt bliver omsat til synlig handling. Fremtidige samtalebriefs bør prioritere status på tidligere løfter før nye udviklingsmål.</p><button className="text-button">Redigér formulering</button></article></div><div className="summary-actions"><button className="secondary">Gem som kladde</button><button className="primary" onClick={onDone}>Godkend og opdatér medarbejderbillede</button></div></div>}

const demoOrders=[{id:"NT-2841",seller:"Christian",amount:23000,status:"Sendt",special:null},{id:"NT-2844",seller:"Jørgen",amount:41800,status:"Sendt",special:7.5},{id:"NT-2846",seller:"Sofie",amount:12900,status:"Afventer lager",special:null},{id:"NT-2849",seller:"Martin",amount:-4800,status:"Returnering",special:null}];
function Compensation({ notify }: any) { const [orders,setOrders]=useState(demoOrders);return <div className="content"><div className="notice"><b>Konfigurerbart provisionsgrundlag — endelig løn afstemmes</b><p>Kun sendte ordrer tæller. Returneringer trækkes fra. Standardsats gælder hele den kvalificerende omsætning: 5% under 200.000 kr., 10% fra 200.000 kr. og 15% fra 300.000 kr.</p></div><div className="tier-grid">{commissionTiers.map((t,i)=><article className="tier-card" key={t.threshold}><small>{i===0?"GRUNDTRIN":`FRA ${money(t.threshold)}`}</small><strong>{t.rate*100}%</strong><span>af hele den sendte omsætning</span></article>)}</div><div className="metric-grid"><Metric label="FORVENTET PROVISION" value="184.250 kr." delta="15 sælgere" note="denne måned"/><Metric label="SENDT OMSÆTNING" value="3.582.000 kr." delta="286 ordrer" note="i grundlaget"/><Metric label="SPECIALSATSAFTALER" value="2" delta="afventer Michael" note="kræver godkendelse" warning/><Metric label="RETURNERINGER" value="−42.800 kr." delta="7 ordrer" note="fratrukket" warning/></div><article className="card table-card"><div className="card-head"><div><span className="kicker">MÅNED · FORELØBIG BEREGNING</span><h3>Godkendelsesoversigt</h3></div><button className="secondary" onClick={()=>notify("Afstemningsrapport klargjort")}>Klargør rapport</button></div><table><thead><tr><th>Sælger</th><th>Sendt omsætning</th><th>Sats</th><th>Estimeret provision</th><th>Til næste trin</th><th>Status</th></tr></thead><tbody>{sales.map((s,i)=>{const revenue=s.amount+i*34000;const c=commissionFor(revenue);const next=nextTierFor(revenue);return <tr key={s.name}><td><b>{s.name}</b></td><td>{money(revenue)}</td><td>{c.rate*100}%</td><td>{money(c.amount)}</td><td>{next?money(next.threshold-revenue):"Toptrin"}</td><td><span className={`pill ${i===1?"amber":""}`}>{i===1?"Specialsats":"Afstemt"}</span></td></tr>})}</tbody></table></article><article className="card order-ledger"><div className="card-head"><div><span className="kicker">ORDREGRUNDLAG</span><h3>Sendt, returneret og specialaftalt</h3></div><span className="muted">Fuld ændringslog i driftssystemet</span></div>{orders.map(o=><div className="ledger-row" key={o.id}><span><b>{o.id}</b><small>{o.seller}</small></span><strong className={o.amount<0?"negative":""}>{money(o.amount)}</strong><span className={`pill ${o.status!=="Sendt"?"amber":""}`}>{o.status}</span>{o.special?<button onClick={()=>notify(`Specialsats på ${o.special}% sendt til godkendelse`)}>Godkend {o.special}%</button>:<span/>}<button className="remove-order" onClick={()=>setOrders(v=>v.filter(x=>x.id!==o.id))}>Fjern</button></div>)}</article></div>; }

function LeadershipCalendar(){return <div className="content"><div className="people-intro"><div><span className="kicker">LEDERRYTME · AUGUST</span><h2>Kalenderen viser dit ledelsesarbejde</h2><p>Ikke endnu en mødekalender — men samtaler, løfter, reviews og opfølgninger, der ellers forsvinder i driften.</p></div><span className="signal-tag attention">4 handlinger kræver opmærksomhed</span></div><div className="calendar-grid"><article className="card"><span className="kicker">I DAG · MANDAG 3. AUGUST</span>{[["09:00","Morgenmøde · Nysalg","Drive"],["10:30","1:1 · Camilla Holm","Coach"],["13:00","Storordre-review · Gensalg","Drive"],["15:30","Rabatter til godkendelse","Decide"]].map(x=><div className="calendar-event" key={x[1]}><time>{x[0]}</time><div><b>{x[1]}</b><small>{x[2]}</small></div><button>Åbn ›</button></div>)}</article><article className="card"><span className="kicker">RYTMENS SUNDHED</span><h3>Det er ved at skride</h3><div className="rhythm-stat"><span>Kvartalssamtaler</span><b>5 / 12</b><small>4 dage bag planen</small></div><div className="rhythm-stat"><span>1:1 denne cyklus</span><b>12 / 16</b><small>Rasmus er 31 dage forsinket</small></div><div className="rhythm-stat"><span>Åbne lederløfter</span><b>8</b><small>2 er forfaldne</small></div></article></div></div>}

function SellerCockpit(){const revenue=184500;const c=commissionFor(revenue);const next=nextTierFor(revenue);return <div className="content seller-view"><div className="seller-hero"><div><span className="kicker">CHRISTIAN · MIT COCKPIT</span><h2>Du er {next?money(next.threshold-revenue):"på toptrinnet"} fra næste provisionstrin</h2><p>Kun sendte og godkendte ordrer er medregnet.</p></div><div className="seller-rate"><small>NUVÆRENDE SATS</small><strong>{c.rate*100}%</strong></div></div><div className="metric-grid"><Metric label="I DAG" value="23.000 kr." delta="3 ordrer" note="sendt"/><Metric label="DENNE UGE" value="87.400 kr." delta="9.711 kr." note="gns. ordre"/><Metric label="DENNE MÅNED" value={money(revenue)} delta="61,5% af mål" note="300.000 kr."/><Metric label="ESTIMERET PROVISION" value={money(c.amount)} delta={next?`${money(next.threshold-revenue)} til ${next.rate*100}%`:"Toptrin"} note=""/></div><article className="card tier-journey"><div className="card-head"><div><span className="kicker">DIN PROVISIONSTRAPPE</span><h3>Jagten på næste niveau</h3></div><span className="pill">Live estimat</span></div><div className="tier-track"><i style={{width:`${revenue/300000*100}%`}}/><span style={{left:"25%"}}>75k</span><span style={{left:"66.6%"}}>200k · 10%</span><span style={{left:"100%"}}>300k · 15%</span></div><p>Når 200.000 kr. er passeret, beregnes 10% af hele den kvalificerende omsætning.</p></article><div className="sales-split"><article className="card"><span className="kicker">SENESTE SALG</span>{demoOrders.slice(0,3).map(o=><div className="my-sale" key={o.id}><span><b>{o.id}</b><small>{o.status}</small></span><strong>{money(Math.abs(o.amount))}</strong></div>)}</article><article className="card"><span className="kicker">MINE TAL</span><div className="summary-row"><span>Gennemsnitsordre · måned</span><b>9.710 kr.</b></div><div className="summary-row"><span>Ordrer · måned</span><b>19</b></div><div className="summary-row"><span>Bedste dag</span><b>41.800 kr.</b></div><div className="summary-row"><span>Placering</span><b>#4 af 16</b></div></article></div></div>}

function Decisions({ notify }: any) { return <div className="content"><div className="decision-grid"><article className="card"><span className="kicker">AFVENTER MICHAEL</span><h2>4 beslutninger blokerer driften</h2><p>Gør ejerafhængighed synlig, og flyt det der kan flyttes med en regel.</p><button className="primary" onClick={() => notify("Ny beslutning kan nu registreres")}>+ Registrér beslutning</button></article>{[
    ["Kundeansvar på gensalg", "Strategi", "Michael", "Høj"], ["Rabat over 22%", "Salg", "Kevin", "Mellem"], ["Specialindkøb over 25.000", "Indkøb", "Michael", "Høj"], ["Godkendelse af provisionsafvigelser", "Administration", "Kevin", "Lav"]
  ].map((d,i)=><article className="card decision" key={d[0]}><span className="number">0{i+1}</span><div><small>{d[1]}</small><h3>{d[0]}</h3><p>Nuværende ejer: <b>{d[2]}</b></p></div><span className={`risk ${d[3]}`}>{d[3]}</span><button>Se regel ›</button></article>)}</div></div>; }

function People(){return <div>{sales.slice(0,4).map((s,i)=><div className="people-row" key={s.name}><span className="person-dot">{s.name[0]}</span><div><b>{s.name}</b><small>{i===3?"Faldende aktivitet":"Stabil udvikling"}</small></div><div className="mini-progress"><i style={{width:`${Math.min(100,s.amount/s.target*100)}%`}}/></div><strong>{Math.round(s.amount/s.target*100)}%</strong></div>)}</div>}
function Timeline(){return <div className="timeline">{[["MAN 3","09:30","1:1 med Jørgen"],["TIR 4","13:00","Storordre-review"],["ONS 5","10:00","Ledelsesmøde med Kevin"],["FRE 7","14:30","Ugestatus · salg"]].map((x,i)=><div key={x[2]}><span>{x[0]}</span><i/><small>{x[1]}</small><b>{x[2]}</b>{i===1&&<em>VIGTIG</em>}</div>)}</div>}

function TvBoard({ onExit }: any) { const leaders=[...sales].sort((a,b)=>b.amount-a.amount);return <div className="tv-board"><div className="tv-head"><div><span className="brand-mark">L</span><b>NORDIC TOOLS · LIVE</b></div><div className="tv-clock">MANDAG · 14:42</div><button onClick={onExit}>Luk tavle ×</button></div><div className="tv-kpis"><div><span>DAGENS OMSÆTNING</span><strong>247.800 <small>kr.</small></strong><p>105% af dagsmål · 38 ordrer</p></div><div><span>MÅNEDENS OMSÆTNING</span><strong>3.582.000 <small>kr.</small></strong><p>64% af mål · 7 nye kunder i dag</p></div></div><div className="tv-main"><section><div className="tv-section-title"><span>LEADERBOARD · MÅNED</span><small>Sendt omsætning</small></div>{leaders.map((s,i)=>{const n=nextTierFor(s.amount);return <div className="leader-row" key={s.name}><b>#{i+1}</b><span className="person-dot">{s.name[0]}</span><div><strong>{s.name}</strong><small>{n?`${money(n.threshold-s.amount)} til ${n.rate*100}% provision`:"Toptrin · 15%"}</small></div><em>{money(s.amount)}</em><div className="leader-progress"><i style={{width:`${Math.min(100,s.amount/300000*100)}%`}}/></div></div>})}</section><aside><span className="kicker">PROVISIONSTRIN</span><h3>To sælgere er tæt på et nyt niveau</h3><div className="threshold-callout"><span>Christian</span><strong>15.500 kr.</strong><small>til 200.000 · 10%</small></div><div className="threshold-callout"><span>Jørgen</span><strong>50.000 kr.</strong><small>til 200.000 · 10%</small></div><div className="latest-feed"><span>SENESTE SALG</span><strong>Christian · 23.000 kr.</strong><small>Sendt fra lageret · for 3 min. siden</small></div></aside></div><div className="ticker"><span>I DAG</span><b>Nysalg: 7 nye kunder · Gensalg: 184.600 kr. · Gennemsnitsordre: 9.420 kr.</b><i>Opdateret nu</i></div></div>; }
